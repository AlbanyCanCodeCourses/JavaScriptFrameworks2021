import "./App.css";
import { useState } from "react";
import ThumbsUpImg from "../src/components/ComponentImg1";
import ThumbsDownImg from "../src/components/componentImg2";

function App() {
  const [wentWell, setWentWell] = useState([
    { likes: 0, dislikes: 0, messages: "To Do" }
  ]);
  const [toImprove, setToImprove] = useState([
    { likes: 0, dislikes: 0, messages: "Work on Car" }
  ]);
  const [actionItems, setActionItems] = useState([
    { likes: 0, dislikes: 0, messages: "Fix Car" }
  ]);

  const newCardWentWell = () => {
    setWentWell([...wentWell, { likes: 0, dislikes: 0, messages: "" }]);
  };
  const newCardToImprove = () => {
    setToImprove([...toImprove, { likes: 0, dislikes: 0, messages: "" }]);
  };
  const newCardActionItems = () => {
    setActionItems([...actionItems, { likes: 0, dislikes: 0, messages: "" }]);
  };
  const updateCardWentWell = (userInput, index) => {
    const newWentWell = [...wentWell];
    newWentWell[index].messages = userInput;
    console.log(newWentWell);
    setWentWell(newWentWell);
  };
  const updateCardToImprove = (userInput, index) => {
    const newToImprove = [...toImprove];
    newToImprove[index].messages = userInput;
    setToImprove(newToImprove);
  };
  const updateCardActionItems = (userInput, index) => {
    const newActionItems = [...actionItems];
    newActionItems[index].messages = userInput;
    setActionItems(newActionItems);
  };

  const deleteCardWentWell = (index) => {
    setWentWell(
      wentWell.filter((item, currentIndex) => currentIndex !== index)
    );
  };
  const deleteCardToImprove = (index) => {
    setToImprove(
      toImprove.filter((item, currentIndex) => currentIndex !== index)
    );
  };
  const deleteCardActionItems = (index) => {
    setActionItems(
      actionItems.filter((item, currentIndex) => currentIndex !== index)
    );
  };

  const shiftLeft = (index, array) => {
    if (array === 0) {
      setActionItems([...actionItems, wentWell[index]]);
      deleteCardWentWell(index); //   setWentWell(wentWell.splice(index, index+1)); // shift left function to object.wentWell.push
    } else if (array === 1) {
      setWentWell([...wentWell, toImprove[index]]);
      deleteCardToImprove(index); //   setToImprove(toImprove.splice(index, 1)); // shift left function to [0]
    } else {
      setToImprove([...toImprove, actionItems[index]]);
      deleteCardActionItems(index); //   setActionItems(actionItems.splice(index, 1)); // shift left function to [1]
    }
  };

  const shiftRight = (index, array) => {
    if (array === 0) {
      setToImprove([...toImprove, wentWell[index]]);
      console.log(toImprove);
      deleteCardWentWell(index); //   setWentWell(wentWell.splice(index, index+1)); // shift left function to object.wentWell.push
    } else if (array === 1) {
      setActionItems([...actionItems, toImprove[index]]);
      deleteCardToImprove(index); //   setToImprove(toImprove.splice(index, 1)); // shift left function to [0]
    } else {
      setWentWell([...wentWell, actionItems[index]]);
      deleteCardActionItems(index); //   setActionItems(actionItems.splice(index, 1)); // shift left function to [1]
    }
  };

  const wentWellThumbsUp = (index) => {
    const newThumbsUp = [...wentWell];
    newThumbsUp[index].likes += 1;
    setWentWell(newThumbsUp);
  };
  const toImproveThumbsUp = (index) => {
    const newThumbsUp = [...toImprove];
    newThumbsUp[index].likes += 1;
    setToImprove(newThumbsUp);
  };
  const actionItemsThumbsUp = (index) => {
    const newThumbsUp = [...actionItems];
    newThumbsUp[index].likes += 1;
    setActionItems(newThumbsUp);
  };
  const wentWellThumbsDown = (index) => {
    const newThumbsDown = [...wentWell];
    newThumbsDown[index].dislikes += 1;
    setWentWell(newThumbsDown);
  };
  const toImproveThumbsDown = (index) => {
    const newThumbsDown = [...toImprove];
    newThumbsDown[index].dislikes += 1;
    setToImprove(newThumbsDown);
  };
  const actionItemsThumbsDown = (index) => {
    const newThumbsDown = [...actionItems];
    newThumbsDown[index].dislikes += 1;
    setActionItems(newThumbsDown);
  };

  return (
    <main className="content row">
      <h1>Retro Board</h1>
      {/* <!-- Layout changer --> */}
      <div>
        Layout &nbsp;<button className="button button-default">Column</button>
      </div>

      {/* <!-- The class "row" is for the layout changer --> */}
      <div className="RetroApp row">
        {/* <!-- Retro category --> */}
        <div className="RetroCategory RetroCategory-1">
          <h2>Went Well</h2>
          {/* <!-- Add a new card button --> */}
          <button
            type="button"
            className="ButtonAdd button button-default"
            aria-label="Add new card"
            title="Add new card"
            onClick={newCardWentWell}
          >
            +
          </button>

          {wentWell.map((card, index) => {
            console.log(card);
            return (
              <div className="RetroCard" aria-label="Retro card">
                {/* <!-- User input --> */}
                <input
                  className="input"
                  placeholder="Enter text here"
                  aria-label="Enter text here"
                  rows="1"
                  value={card.messages}
                  onChange={(e) => updateCardWentWell(e.target.value, index)}
                />

                <div className="button-group">
                  <button
                    type="button"
                    className="button button-left"
                    title="Move left"
                    onClick={() => shiftLeft(index, 0)}
                  >
                    <img
                      src="angleLeft.svg"
                      alt="Move left"
                      width="12"
                      height="12"
                    />
                  </button>
                  <button
                    type="button"
                    className="button button-delete"
                    title="Delete"
                    onClick={() => deleteCardWentWell(index)}
                  >
                    <img
                      src="timesCircle.svg"
                      alt="Delete"
                      width="12"
                      height="12"
                    />
                  </button>
                  <div>
                    <button
                      type="button"
                      className="button button-left"
                      title="Like"
                      onClick={() => wentWellThumbsUp(index)}
                    >
                      <ThumbsUpImg
                        src="thumbsUp.svg"
                        alt="Like"
                        width="12"
                        height="12"
                      />
                      {card.likes}
                    </button>
                    <button
                      type="button"
                      className="button button-left"
                      title="Dislike"
                      onClick={() => wentWellThumbsDown(index)}
                    >
                      <ThumbsDownImg
                        src="thumbsDown.svg"
                        alt="Dislike"
                        width="12"
                        height="12"
                      />
                      {card.dislikes}
                    </button>
                    <button
                      type="button"
                      className="button button-right"
                      title="Move right"
                      onClick={() => shiftRight(index, 0)}
                    >
                      <img
                        src="angleRight.svg"
                        alt="Move right"
                        width="12"
                        height="12"
                      />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* <!-- Retro category --> */}
        <div className="RetroCategory RetroCategory-2">
          <h2>To Improve</h2>
          <button
            type="button"
            className="ButtonAdd button button-default"
            aria-label="Add to new card"
            title="Add to new card"
            onClick={newCardToImprove}
          >
            +
          </button>
          {toImprove.map((card, index) => {
            return (
              <div className="RetroCard" aria-label="Retro card">
                {/* <!-- User input --> */}
                <input
                  className="input"
                  placeholder="Enter text here"
                  aria-label="Enter text here"
                  rows="1"
                  value={card.messages}
                  onChange={(e) => updateCardToImprove(e.target.value, index)}
                />

                <div className="button-group">
                  <button
                    type="button"
                    className="button button-left"
                    title="Move left"
                    onClick={() => shiftLeft(index, 1)}
                  >
                    <img
                      src="angleLeft.svg"
                      alt="Move left"
                      width="12"
                      height="12"
                    />
                  </button>
                  <button
                    type="button"
                    className="button button-delete"
                    title="Delete"
                    onClick={() => deleteCardToImprove(index)}
                  >
                    <img
                      src="timesCircle.svg"
                      alt="Delete"
                      width="12"
                      height="12"
                    />
                  </button>
                  <div>
                    <button
                      type="button"
                      className="button button-left"
                      title="Like"
                      onClick={() => toImproveThumbsUp(index)}
                    >
                      <ThumbsUpImg
                        src="thumbsUp.svg"
                        alt="Like"
                        width="12"
                        height="12"
                      />
                      {card.likes}
                    </button>
                    <button
                      type="button"
                      className="button button-left"
                      title="Dislike"
                      onClick={() => toImproveThumbsDown(index)}
                    >
                      <ThumbsDownImg
                        src="thumbsDown.svg"
                        alt="Dislike"
                        width="12"
                        height="12"
                      />
                      {card.dislikes}
                    </button>
                    <button
                      type="button"
                      className="button button-right"
                      title="Move right"
                      onClick={() => shiftRight(index, 1)}
                    >
                      <img
                        src="angleRight.svg"
                        alt="Move right"
                        width="12"
                        height="12"
                      />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* <!-- Retro category --> */}
        <div className="RetroCategory RetroCategory-3">
          <h2>Action Items</h2>
          <button
            type="button"
            className="ButtonAdd button button-default"
            aria-label="Add to new card"
            title="Add to new card"
            onClick={newCardActionItems}
          >
            +
          </button>
          {actionItems.map((card, index) => {
            return (
              <div className="RetroCard" aria-label="Retro card">
                {/* <!-- User input --> */}
                <input
                  className="input"
                  placeholder="Enter text here"
                  aria-label="Enter text here"
                  rows="1"
                  value={card.messages}
                  onChange={(e) => updateCardActionItems(e.target.value, index)}
                />

                <div className="button-group">
                  <button
                    type="button"
                    className="button button-left"
                    title="Move left"
                    onClick={() => shiftLeft(index, 2)}
                  >
                    <img
                      src="angleLeft.svg"
                      alt="Move left"
                      width="12"
                      height="12"
                    />
                  </button>
                  <button
                    type="button"
                    className="button button-delete"
                    title="Delete"
                    onClick={() => deleteCardActionItems(index)}
                  >
                    <img
                      src="timesCircle.svg"
                      alt="Delete"
                      width="12"
                      height="12"
                    />
                  </button>
                  <div>
                    <button
                      type="button"
                      className="button button-left"
                      title="Like"
                      onClick={() => actionItemsThumbsUp(index)}
                    >
                      <ThumbsUpImg
                        src="thumbsUp.svg"
                        alt="Like"
                        width="12"
                        height="12"
                      />
                      {card.likes}
                    </button>
                    <button
                      type="button"
                      className="button button-left"
                      title="Dislike"
                      onClick={() => actionItemsThumbsDown(index)}
                    >
                      <ThumbsDownImg
                        src="thumbsDown.svg"
                        alt="Dislike"
                        width="12"
                        height="12"
                      />
                      {card.dislikes}
                    </button>
                    <button
                      type="button"
                      className="button button-right"
                      title="Move right"
                      onClick={() => shiftRight(index, 2)}
                    >
                      <img
                        src="angleRight.svg"
                        alt="Move right"
                        width="12"
                        height="12"
                      />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </main>
  );
}

export default App;
