# First Project Retro Board

In Visual Studio code, press `command+shift+v` (Mac) or `ctrl+shift+v` (Windows) to open a Markdown preview.

## How to Use

Load the file in your text editor. Once the window is open you can interact with the app. The plus button adds a new card to the column. You can then interact with each card as you please. Move the card to the left or right. Remove cards, edit their title and add likes or dislikes to the card.
